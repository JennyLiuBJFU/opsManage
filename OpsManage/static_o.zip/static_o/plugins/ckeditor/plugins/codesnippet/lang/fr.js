﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","fr",{button:"Insérer un extrait de code",codeContents:"Contenu du code",emptySnippetError:"Un extrait de code ne peut pas être vide.",language:"Langue",title:"Extrait de code",pathName:"extrait de code"});