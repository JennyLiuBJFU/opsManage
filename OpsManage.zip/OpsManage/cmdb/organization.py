from cmdb.models import *
import json

zhognxianju = Organization.objects.get()